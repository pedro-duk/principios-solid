export default class Cliente {
    constructor(
        public readonly id: number,
        public readonly nome: string,
        public readonly email: string) { }
}
