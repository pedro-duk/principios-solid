export enum Cargos {
    Estagiario = "Estagiário",
    Junior = "Júnior",
    Pleno = "Pleno",
    Senior = "Sênior",
}