# solid
Alura's course project about SOLID using TypeScript
